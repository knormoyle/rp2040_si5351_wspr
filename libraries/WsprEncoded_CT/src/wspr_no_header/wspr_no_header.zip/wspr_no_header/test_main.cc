#include <cstdio>
#include <cstring>
#include <math.h>

#include "WsprEncoded.h"


// Track pass/fail across the whole run instead of bailing on first error,
// so a single failure does not hide downstream issues.
static int g_fail_count = 0;
static int g_check_count = 0;

#define CHECK(cond, msg)                                                    \
    do {                                                                    \
        ++g_check_count;                                                    \
        if (!(cond)) {                                                      \
            ++g_fail_count;                                                 \
            printf("  FAIL: %s (line %d)\n", (msg), __LINE__);              \
        }                                                                   \
    } while (0)

#define CHECK_NEAR(actual, expected, tol, msg)                              \
    do {                                                                    \
        ++g_check_count;                                                    \
        double check_a = (actual);                                          \
        double check_e = (expected);                                        \
        if (fabs(check_a - check_e) > (tol)) {                              \
            ++g_fail_count;                                                 \
            printf("  FAIL: %s: got %f, want %f (tol %f) (line %d)\n",      \
                   (msg), check_a, check_e,                                 \
                   static_cast<double>(tol), __LINE__);                     \
        }                                                                   \
    } while (0)


// Copy the encoded WSPR Type 1 fields (callsign, grid4, power_dbm) from
// `src` to `dst`. This is the wire-equivalent of "transmit, receive".
static void TransferWire(const WsprMessageRegularType1& src,
                         WsprMessageRegularType1& dst) {
    dst.SetCallsign(src.GetCallsign());
    dst.SetGrid4(src.GetGrid4());
    dst.SetPowerDbm(src.GetPowerDbm());
}


/////////////////////////////////////////////////////////////////
// Basic Telemetry round-trip
/////////////////////////////////////////////////////////////////

static void TestBasicRoundTrip(const char* label,
                               const char* id13,
                               const char* grid56,
                               int32_t     altitude_meters,
                               int32_t     temperature_celsius,
                               double      voltage_volts,
                               int32_t     speed_knots,
                               bool        gps_is_valid) {
    printf("[basic] %s\n", label);

    WsprMessageTelemetryBasic enc;
    CHECK(enc.SetId13(id13), "SetId13");
    CHECK(enc.SetGrid56(grid56), "SetGrid56");
    CHECK(enc.SetAltitudeMeters(altitude_meters), "SetAltitudeMeters");
    CHECK(enc.SetTemperatureCelsius(temperature_celsius),
          "SetTemperatureCelsius");
    CHECK(enc.SetVoltageVolts(voltage_volts), "SetVoltageVolts");
    CHECK(enc.SetSpeedKnots(speed_knots), "SetSpeedKnots");
    CHECK(enc.SetGpsIsValid(gps_is_valid), "SetGpsIsValid");

    enc.Encode();

    printf("  encoded: call=%s grid=%s power=%u\n",
           enc.GetCallsign(), enc.GetGrid4(),
           static_cast<unsigned>(enc.GetPowerDbm()));

    // Round-trip through a fresh decoder so we are sure decode populates
    // every field and does not just observe the encoder's state.
    WsprMessageTelemetryBasic dec;
    CHECK(dec.SetId13(id13), "decoder SetId13");
    TransferWire(enc, dec);
    CHECK(dec.Decode(), "Decode");

    // Encoded altitude is rounded to nearest 20m. Compute the expected
    // decoded altitude the same way the encoder rounds (half-up).
    int32_t expected_alt = ((altitude_meters + 10) / 20) * 20;
    if (altitude_meters < 0) { expected_alt = 0; }
    if (expected_alt > 21340) { expected_alt = 21340; }

    // Encoded speed is rounded to nearest 2 knots.
    int32_t expected_speed = ((speed_knots + 1) / 2) * 2;
    if (speed_knots < 0) { expected_speed = 0; }
    if (expected_speed > 82) { expected_speed = 82; }

    CHECK(strcmp(dec.GetGrid56(), grid56) == 0, "grid56 round-trip");
    CHECK(dec.GetAltitudeMeters() == static_cast<uint16_t>(expected_alt),
          "altitude round-trip");
    CHECK(dec.GetTemperatureCelsius() ==
              static_cast<int8_t>(temperature_celsius),
          "temperature round-trip");
    CHECK_NEAR(dec.GetVoltageVolts(), voltage_volts, 0.05,
               "voltage round-trip");
    CHECK(dec.GetSpeedKnots() == static_cast<uint8_t>(expected_speed),
          "speed round-trip");
    CHECK(dec.GetGpsIsValid() == gps_is_valid, "gps round-trip");
}


/////////////////////////////////////////////////////////////////
// Extended Telemetry (User-Defined) round-trip
/////////////////////////////////////////////////////////////////

struct ExtFieldSpec {
    const char* name;
    double      low_value;
    double      high_value;
    double      step_size;
    double      set_value;
    double      expected_value;   // after step rounding
};

static void TestExtUserDefinedRoundTrip(const char*         label,
                                        uint8_t             field_count,
                                        const ExtFieldSpec* fields,
                                        uint8_t             num_fields,
                                        uint8_t             hdr_slot,
                                        const char*         id13) {
    printf("[ext-user] %s\n", label);

    WsprMessageTelemetryExtendedUserDefined enc(field_count);

    for (uint8_t i = 0; i < num_fields; ++i) {
        bool ok = enc.DefineField(fields[i].name,
                                  fields[i].low_value,
                                  fields[i].high_value,
                                  fields[i].step_size);
        if (!ok) {
            printf("  DefineField(%s) failed: %s\n",
                   fields[i].name, enc.GetDefineFieldErr());
        }
        CHECK(ok, "DefineField");
    }

    CHECK(enc.SetId13(id13), "SetId13");
    enc.SetHdrSlot(hdr_slot);
    for (uint8_t i = 0; i < num_fields; ++i) {
        CHECK(enc.Set(fields[i].name, fields[i].set_value), "Set field");
    }

    enc.Encode();

    printf("  encoded: call=%s grid=%s power=%u\n",
           enc.GetCallsign(), enc.GetGrid4(),
           static_cast<unsigned>(enc.GetPowerDbm()));

    // Fresh decoder, same field schema, transferred wire fields.
    WsprMessageTelemetryExtendedUserDefined dec(field_count);
    for (uint8_t i = 0; i < num_fields; ++i) {
        CHECK(dec.DefineField(fields[i].name,
                              fields[i].low_value,
                              fields[i].high_value,
                              fields[i].step_size),
              "decoder DefineField");
    }
    CHECK(dec.SetId13(id13), "decoder SetId13");

    TransferWire(enc, dec);
    CHECK(dec.Decode(), "Decode");

    CHECK(dec.GetHdrSlot() == hdr_slot, "hdr_slot round-trip");

    for (uint8_t i = 0; i < num_fields; ++i) {
        // Use a tolerance of half the step size to absorb the rounding
        // that happens during encode (set value -> nearest representable).
        double tol = fields[i].step_size / 2.0 + 1e-9;
        CHECK_NEAR(dec.Get(fields[i].name),
                   fields[i].expected_value,
                   tol,
                   fields[i].name);
    }
}


int main() {
    // ---------------------------------------------------------------
    // Wspr band/power lookups
    // ---------------------------------------------------------------
    {
        printf("[wspr] band/power lookups\n");
        CHECK(Wspr::GetDialFreqFromBandStr("20m") == 14095600UL,
              "20m dial freq");
        CHECK(Wspr::PowerDbmInSet(23),  "power 23 in set");
        CHECK(!Wspr::PowerDbmInSet(24), "power 24 not in set");
        CHECK(strcmp(Wspr::GetDefaultBandIfNotValid("nope"), "20m") == 0,
              "default band fallback");
    }

    // ---------------------------------------------------------------
    // ChannelMap
    // ---------------------------------------------------------------
    {
        printf("[channel-map] channel 0 on 20m\n");
        WsprChannelMap::ChannelDetails cd =
            WsprChannelMap::GetChannelDetails("20m", 0);
        printf("  id13=%s min=%u lane=%u dial=%u\n",
               cd.id13,
               static_cast<unsigned>(cd.min),
               static_cast<unsigned>(cd.lane),
               static_cast<unsigned>(cd.freq_dial));
        CHECK(cd.freq_dial == 14095600UL, "channel dial freq");
    }

    // ---------------------------------------------------------------
    // Regular Type1 validation
    // ---------------------------------------------------------------
    {
        printf("[type1] validation\n");
        WsprMessageRegularType1 m;
        CHECK(m.SetCallsign("KD2EPF"), "valid callsign");
        CHECK(m.SetGrid4("FN20"),      "valid grid");
        CHECK(m.SetPowerDbm(23),       "valid power");
        CHECK(!m.SetCallsign("kd2epf"), "reject lowercase callsign");
        CHECK(!m.SetPowerDbm(24),       "reject bad power");
    }

    // ---------------------------------------------------------------
    // Basic telemetry round-trips: nominal, low extremes, high extremes,
    // mid range, and step-rounding cases
    // ---------------------------------------------------------------
    TestBasicRoundTrip("nominal",
                       "Q3", "AB", 5000, -10, 3.7, 40, true);

    // Low end of every range
    TestBasicRoundTrip("low extremes",
                       "00", "AA", 0, -50, 3.0, 0, false);

    // High end of every range
    TestBasicRoundTrip("high extremes",
                       "19", "XX", 21340, 39, 4.95, 82, true);

    // Mid range with gps invalid
    TestBasicRoundTrip("mid, gps invalid",
                       "Q5", "MN", 10000, 0, 4.0, 20, false);

    // Step rounding: altitude 5010 -> 5000 or 5020; speed 41 -> 40 or 42
    TestBasicRoundTrip("step rounding",
                       "Q0", "GH", 5010, 15, 3.85, 41, true);

    // ---------------------------------------------------------------
    // Extended user-defined: small schema
    // ---------------------------------------------------------------
    {
        ExtFieldSpec fields[] = {
            { "battery", 3.0,   4.5,    0.05, 3.7,   3.7   },
            { "temp",   -50.0,  50.0,   1.0,  22.0,  22.0  },
            { "counter", 0.0,   1023.0, 1.0,  500.0, 500.0 },
        };
        TestExtUserDefinedRoundTrip("3 fields, slot 2",
                                    /*field_count=*/5,
                                    fields, 3,
                                    /*hdr_slot=*/2,
                                    "Q3");
    }

    // ---------------------------------------------------------------
    // Extended user-defined: low and high boundary values
    // ---------------------------------------------------------------
    {
        // At low boundaries
        ExtFieldSpec lows[] = {
            { "a", 0.0,   10.0, 1.0,    0.0,  0.0 },
            { "b", -1.0,  1.0,  0.05,  -1.0, -1.0 },
        };
        TestExtUserDefinedRoundTrip("low boundaries",
                                    /*field_count=*/4,
                                    lows, 2,
                                    /*hdr_slot=*/0,
                                    "00");

        // At high boundaries
        ExtFieldSpec highs[] = {
            { "a", 0.0,   10.0, 1.0,   10.0, 10.0 },
            { "b", -1.0,  1.0,  0.05,  1.0,  1.0  },
        };
        TestExtUserDefinedRoundTrip("high boundaries",
                                    /*field_count=*/4,
                                    highs, 2,
                                    /*hdr_slot=*/4,
                                    "19");
    }

    // ---------------------------------------------------------------
    // Extended user-defined: many small fields packed close to the
    // 29.180-bit budget
    // ---------------------------------------------------------------
    {
        ExtFieldSpec many[] = {
            { "f0",  0.0, 7.0,  1.0, 5.0,  5.0  },   // 3 bits
            { "f1",  0.0, 7.0,  1.0, 0.0,  0.0  },   // 3 bits
            { "f2",  0.0, 15.0, 1.0, 9.0,  9.0  },   // 4 bits
            { "f3",  0.0, 15.0, 1.0, 15.0, 15.0 },   // 4 bits
            { "f4",  0.0, 31.0, 1.0, 17.0, 17.0 },   // 5 bits
            { "f5",  0.0, 1.0,  1.0, 1.0,  1.0  },   // 1 bit
            { "f6",  0.0, 1.0,  1.0, 0.0,  0.0  },   // 1 bit
            // total ~21 bits, well under budget
        };
        TestExtUserDefinedRoundTrip("7 packed fields",
                                    /*field_count=*/8,
                                    many, 7,
                                    /*hdr_slot=*/1,
                                    "Q5");
    }

    // ---------------------------------------------------------------
    // Extended user-defined: step rounding inside Set()
    // (set 3.72 with step 0.05 -> nearest is 3.70)
    // ---------------------------------------------------------------
    {
        ExtFieldSpec rounding[] = {
            { "battery", 3.0, 4.5, 0.05, 3.72, 3.70 },
        };
        TestExtUserDefinedRoundTrip("step rounding",
                                    /*field_count=*/2,
                                    rounding, 1,
                                    /*hdr_slot=*/0,
                                    "Q0");
    }

    // ---------------------------------------------------------------
    // Capacity rejection
    // ---------------------------------------------------------------
    {
        printf("[ext] capacity rejection\n");
        WsprMessageTelemetryExtendedUserDefined m(2);
        CHECK(m.DefineField("a", 0, 10, 1), "1st field");
        CHECK(m.DefineField("b", 0, 10, 1), "2nd field");
        CHECK(!m.DefineField("c", 0, 10, 1), "3rd rejected");
        printf("  reason: %s\n", m.GetDefineFieldErr());
    }

    // ---------------------------------------------------------------
    // Summary
    // ---------------------------------------------------------------
    printf("\n%d/%d checks passed, %d failed\n",
           g_check_count - g_fail_count, g_check_count, g_fail_count);

    return g_fail_count == 0 ? 0 : 1;
}
