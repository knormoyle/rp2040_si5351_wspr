#ifndef WSPR_WSPR_UTL_H_
#define WSPR_WSPR_UTL_H_

#include <cctype>
#include <cstdint>
#include <cstring>

// Note: The namespace is PascalCase to preserve the project's existing public
// API. Strict Google style would rename it to `wspr_utl`, but doing so would
// break every caller of this library.
namespace WsprUtl {
class CString {
public:
    CString() {}

    CString(const char* str, size_t buf_capacity) {
        Target(const_cast<char*>(str), buf_capacity);
    }

    void Target(char* buf, size_t buf_capacity) {
        if (buf && buf_capacity) {
            buf_ = buf;
            buf_capacity_ = buf_capacity;
        }
    }

    void Clear() {
        if (buf_capacity_) {
            memset(buf_, 0, buf_capacity_);
        }
    }

    void Set(const char* str) {
        if (str && buf_capacity_) {
            Clear();
            strncpy(buf_, str, buf_capacity_ - 1);
        }
    }

    void ToUpper() {
        if (buf_capacity_) {
            char* p = buf_;
            while (*p != '\0') {
                *p = toupper(*p);
                ++p;
            }
        }
    }

    bool IsPaddedLeft() {
        return buf_capacity_ && buf_[0] == ' ';
    }

    bool IsPaddedRight() {
        bool ret_val = false;
        size_t len = Len();
        if (len) {
            ret_val = buf_[len - 1] == ' ';
        }
        return ret_val;
    }

    bool IsUppercase() {
        // empty string considered uppercase
        // non-alpha chars are considered uppercase
        bool ret_val = false;
        if (buf_capacity_) {
            if (buf_[0] == '\0') {
                ret_val = true;
            } else {
                char* p = buf_;
                while (*p != '\0' && *p == toupper(*p)) {
                    ++p;
                }
                ret_val = *p == '\0';
            }
        }
        return ret_val;
    }

    bool IsEqual(const char* str) {
        bool ret_val = false;
        if (str && buf_capacity_) {
            ret_val = strcmp(buf_, str) == 0;
        }
        return ret_val;
    }

    size_t Len() {
        size_t ret_val = 0;
        if (buf_capacity_) {
            ret_val = strlen(buf_);
        }
        return ret_val;
    }

    // Shift left any spaces.
    void TrimLeft() {
        if (buf_capacity_) {
            // find first non-space char
            size_t idx_first = 0;
            while (buf_[idx_first] == ' ') {
                ++idx_first;
            }
            if (buf_[idx_first] == '\0') {
                // whole string is whitespace; null-terminate at start
                Clear();
            } else if (idx_first == 0) {
                // nothing to do
            } else {
                // there was some whitespace, shift
                size_t len = Len();
                memmove(buf_, &buf_[idx_first], len - idx_first);
                buf_[len - idx_first] = '\0';
            }
        }
    }

    void TrimRight() {
        if (buf_capacity_) {
            size_t len = Len();
            for (int i = static_cast<int>(len) - 1; i >= 0; --i) {
                if (buf_[i] == ' ') {
                    buf_[i] = '\0';
                } else {
                    break;
                }
            }
        }
    }

    void Trim() {
        TrimRight();
        TrimLeft();
    }

    const char* Get() const {
        return buf_;
    }

private:
    char* buf_ = nullptr;
    size_t buf_capacity_ = 0;
};

// Rotate a uint8_t array of length 5 by `count` positions.
//
// Positive values rotate right, negative values rotate left, zero is no-op.
//
// This is the only rotation use site in the codebase (minute lists). It is
// intentionally not generic since templates are not used here.
inline void Rotate5(uint8_t val_list[5], int count) {
    const int kSize = 5;
    // normalize count into [0, kSize) representing a right rotation
    int right = count % kSize;
    if (right < 0) {
        right += kSize;
    }
    if (right == 0) {
        return;
    }
    uint8_t tmp[5];
    for (int i = 0; i < kSize; ++i) {
        tmp[(i + right) % kSize] = val_list[i];
    }
    for (int i = 0; i < kSize; ++i) {
        val_list[i] = tmp[i];
    }
}
}  // namespace WsprUtl

#endif  // WSPR_WSPR_UTL_H_
